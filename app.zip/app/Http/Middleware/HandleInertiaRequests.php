<?php

namespace App\Http\Middleware;

use App\Models\Capability;
use App\Models\Category;
use App\Models\Milestone;
use App\Models\Story;
use Illuminate\Http\Request;
use Inertia\Middleware;

class HandleInertiaRequests extends Middleware
{
    protected $rootView = 'app';
 
    public function version(Request $request): ?string
    {
        return parent::version($request);
    }
 
    public function share(Request $request): array
    {
        return array_merge(parent::share($request), [
            'auth' => [
                'user'        => $request->user(),
                'roles'       => $request->user()?->getRoleNames(),
                'permissions' => $request->user()?->getAllPermissions()->pluck('name'),
            ],
            'flash' => [
                'message' => fn () => $request->session()->get('message'),
            ],
            'aboutCounts' => $request->user() ? [
                'stories'      => Story::count(),
                'milestones'   => Milestone::count(),
                'capabilities' => Capability::count(),
            ] : null,
 
            // ── Navigation category tree (lazy, shared on every page) ────────
            // Used by AppLayout to render the Products mega menu.
            // Only active root categories + their direct children are loaded.
            'navCategories' => fn () => Category::with(['children' => fn($q) => $q
                    ->active()
                    ->ordered()
                    ->with(['children' => fn($q2) => $q2->active()->ordered()])
                ])
                ->roots()
                ->active()
                ->ordered()
                ->get()
                ->map(fn($root) => [
                    'id'       => $root->id,
                    'name'     => $root->name,
                    'slug'     => $root->slug,
                    'icon'     => $root->icon,
                    'children' => $root->children->map(fn($sub) => [
                        'id'       => $sub->id,
                        'name'     => $sub->name,
                        'slug'     => $sub->slug,
                        'icon'     => $sub->icon,
                        'children' => $sub->children->map(fn($leaf) => [
                            'id'   => $leaf->id,
                            'name' => $leaf->name,
                            'slug' => $leaf->slug,
                        ])->all(),
                    ])->all(),
                ])->all(),
        ]);
    }
}
