<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Inertia\Inertia;

class CategoryController extends Controller
{
//    public function index(Request $request)
// {
//     $search = $request->get('search');
//     $categorySlug = $request->get('category');

//     $rootCategories = Category::whereNull('parent_id')
//         ->withCount('products')
//         ->get()
//         ->map(fn($cat) => [
//             'id'            => $cat->id,
//             'name'          => $cat->name,
//             'slug'          => $cat->slug,
//             'icon'          => $cat->icon ?? null,
//             'product_count' => $cat->products_count,
//         ]);

//     $products = \App\Models\Product::query()
//         ->with('category')
//         ->when($search, fn($q) => $q->where('name', 'like', "%{$search}%"))
//         ->when($categorySlug, fn($q) => $q->whereHas('category', fn($q) => $q->where('slug', $categorySlug)))
//         ->paginate(12)
//         ->withQueryString()
//         ->through(fn($p) => [
//             'id'        => $p->id,
//             'name'      => $p->name,
//             'slug'      => $p->slug,
//             'image_url' => $p->image_url ?? null,
//             'category'  => $p->category ? ['name' => $p->category->name] : null,
//         ]);

//     return Inertia::render('Categories/CategoriesPage', [
//         'categories'     => Category::tree(),
//         'rootCategories' => $rootCategories,
//         'products'       => $products,
//         'filters'        => $request->only(['search', 'category']),
//     ]);
// }

// ─── Replace your existing public index() with this method ───────────────────
// This is the PUBLIC product catalogue page — separate from the admin panel routes.
//
// Route (add to web.php, outside the admin auth middleware group):
//   Route::get('/categories', [CategoryController::class, 'publicIndex'])->name('catalogue');

public function index(Request $request)
{
    $search       = $request->get('search');
    $categorySlug = $request->get('category');

    // ── Sidebar tree ──────────────────────────────────────────────────────────
    // Build root categories + their direct children for the sidebar.
    // Only active categories are shown on the public site.
    // product_count on each node counts products directly assigned to that category.
    // Clicking a parent shows its products AND all descendants' products (see below).
    $categoryTree = Category::whereNull('parent_id')
        ->where('is_active', true)
        ->orderBy('sort_order')
        ->with([
            'children' => function ($q) {
                $q->where('is_active', true)
                  ->orderBy('sort_order')
                  ->withCount('products')
                  ->with([
                      'children' => function ($q2) {
                          // Third level (and beyond is recursive in the model via allChildren,
                          // but for the sidebar we load two levels explicitly for performance.
                          $q2->where('is_active', true)
                             ->orderBy('sort_order')
                             ->withCount('products');
                      },
                  ]);
            },
        ])
        ->withCount('products')
        ->get()
        ->map(fn ($cat) => $this->mapCategoryForSidebar($cat));

    // ── Category ID filter ────────────────────────────────────────────────────
    // When a category is selected, products from that node AND every descendant
    // are returned — so selecting "Electronics" also surfaces "Phones", "Laptops", etc.
    $filterIds = null;
    if ($categorySlug) {
        $selected = Category::where('slug', $categorySlug)
            ->where('is_active', true)
            ->with('allChildren')
            ->first();

        if ($selected) {
            $filterIds = $this->collectAllIds($selected);
        }
    }

    // ── Product query ─────────────────────────────────────────────────────────
    $products = \App\Models\Product::query()
        ->with('category')
        ->where('is_active', true)
        ->when($search,    fn ($q) => $q->where('name', 'like', "%{$search}%"))
        ->when($filterIds, fn ($q) => $q->whereIn('category_id', $filterIds))
        ->orderBy('sort_order')
        ->paginate(12)
        ->withQueryString()
        ->through(fn ($p) => [
            'id'        => $p->id,
            'name'      => $p->name,
            'slug'      => $p->slug,
            'image_url' => $p->image_url ?? null,
            'category'  => $p->category
                ? ['name' => $p->category->name, 'slug' => $p->category->slug]
                : null,
        ]);

    return Inertia::render('Categories/CategoriesPage', [
        // Full tree for the Navbar mega-menu component
        'categories'   => Category::tree(),

        // Sidebar tree (active only, with product counts per node)
        'categoryTree' => $categoryTree,

        'products' => $products,
        'filters'  => $request->only(['search', 'category']),
    ]);
}

// ─── Private helpers ──────────────────────────────────────────────────────────

/**
 * Recursively collect this category's ID + every descendant ID.
 * Used to filter products when a parent category is selected.
 */
private function collectAllIds(Category $category): array
{
    $ids = [$category->id];

    foreach ($category->allChildren as $child) {
        $ids = array_merge($ids, $this->collectAllIds($child));
    }

    return $ids;
}

/**
 * Map a category model to the array shape the sidebar expects.
 * Runs recursively so the sidebar can render unlimited nesting.
 */
private function mapCategoryForSidebar(Category $cat): array
{
    return [
        'id'            => $cat->id,
        'name'          => $cat->name,
        'slug'          => $cat->slug,
        'icon'          => $cat->icon,
        'product_count' => $cat->products_count,
        // Recursively map children so the sidebar tree is fully nested
        'children'      => $cat->children->map(
            fn ($child) => $this->mapCategoryForSidebar($child)
        )->values()->all(),
    ];
}
  
}