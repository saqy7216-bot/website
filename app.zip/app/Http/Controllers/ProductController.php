<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Inertia\Inertia;

class ProductController extends Controller
{
   public function index(Request $request)
    {
        $categorySlug = $request->query('category');
        $outputs      = (array) array_filter((array) $request->query('output', []));
 
        $query = Product::active()->ordered()->with('category');
 
        // ── Category filter (includes all descendants) ──────────────────────
        if ($categorySlug) {
            $category    = Category::where('slug', $categorySlug)->firstOrFail();
            $categoryIds = $this->descendantIds($category);
            $query->whereIn('category_id', $categoryIds);
        }
 
        // ── Rated-output filter (matches spec label="Rated Output") ──────────
        // Done in PHP after query because JSON_CONTAINS across nested array
        // objects varies by DB engine. Fine for typical catalogue sizes.
        $products = $query->get();
 
        if (!empty($outputs)) {
            $products = $products->filter(function (Product $p) use ($outputs) {
                foreach ($p->specs ?? [] as $spec) {
                    if (
                        isset($spec['label'], $spec['value']) &&
                        strtolower($spec['label']) === 'rated output' &&
                        in_array($spec['value'], $outputs, true)
                    ) {
                        return true;
                    }
                }
                return false;
            });
        }
 
        // ── Paginate the (possibly filtered) collection ──────────────────────
        $perPage     = 12;
        $page        = (int) $request->query('page', 1);
        $total       = $products->count();
        $sliced      = $products->forPage($page, $perPage)->values();
 
        $paginated = new \Illuminate\Pagination\LengthAwarePaginator(
            $sliced,
            $total,
            $perPage,
            $page,
            ['path' => $request->url(), 'query' => $request->query()]
        );
 
        // ── Collect distinct "Rated Output" values for the sidebar filter ────
        $allActive   = Product::active()->get(['specs']);
        $ratedOutputs = $allActive
            ->flatMap(fn($p) => collect($p->specs ?? [])
                ->filter(fn($s) => isset($s['label']) && strtolower($s['label']) === 'rated output')
                ->pluck('value'))
            ->unique()
            ->sort()
            ->values()
            ->toArray();
 
        return Inertia::render('Products/Index', [
            'products'           => $paginated,
            'ratedOutputs'       => $ratedOutputs,
            'filters'            => [
                'category' => $categorySlug,
                'output'   => $outputs,
            ],
            'breadcrumbs'        => $this->buildListBreadcrumb($categorySlug),
        ]);
    }
 
    // ─── Public detail ────────────────────────────────────────────────────────
 
    public function show(string $slug)
    {
        $product = Product::active()
            ->where('slug', $slug)
            ->with('category.parent.parent')
            ->firstOrFail();
 
        $related = Product::active()
            ->where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->ordered()
            ->limit(4)
            ->get();
 
        // Breadcrumb: Home → Products → [Category] → Product name
        $breadcrumbs = $this->buildDetailBreadcrumb($product);
 
        return Inertia::render('Products/Show', [
            'product'     => $product,
            'related'     => $related,
            'breadcrumbs' => $breadcrumbs,
        ]);
    }
 
    // ─── Helpers ─────────────────────────────────────────────────────────────
 
    private function descendantIds(Category $category): array
    {
        $category->loadMissing('allChildren');
        $ids = [$category->id];
 
        foreach ($category->allChildren as $child) {
            $ids = array_merge($ids, $this->descendantIds($child));
        }
 
        return $ids;
    }
 
    private function buildListBreadcrumb(?string $categorySlug): array
    {
        $crumbs = [
            ['label' => 'Home',     'href' => '/'],
            ['label' => 'Products', 'href' => '/products'],
        ];
 
        if ($categorySlug) {
            $cat = Category::where('slug', $categorySlug)->first();
            if ($cat) {
                $crumbs[] = ['label' => $cat->name, 'href' => null];
            }
        }
 
        return $crumbs;
    }
 
    private function buildDetailBreadcrumb(Product $product): array
    {
        $crumbs = [
            ['label' => 'Home',     'href' => '/'],
            ['label' => 'Products', 'href' => '/products'],
        ];
 
        // Walk the category ancestor chain
        $cat = $product->category;
        $chain = [];
        while ($cat) {
            $chain[] = $cat;
            $cat = $cat->parent ?? null;
        }
 
        foreach (array_reverse($chain) as $ancestor) {
            $crumbs[] = [
                'label' => $ancestor->name,
                'href'  => '/products?category=' . $ancestor->slug,
            ];
        }
 
        $crumbs[] = ['label' => $product->name, 'href' => null];
 
        return $crumbs;
    }
}